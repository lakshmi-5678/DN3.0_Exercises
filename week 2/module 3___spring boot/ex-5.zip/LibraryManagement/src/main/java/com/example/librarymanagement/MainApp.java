package com.example.librarymanagement;

import com.example.librarymanagement.service.BookService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
    public static void main(String[] args) {
        // Load the Spring context from the XML configuration file
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        // Retrieve the BookService bean from the Spring container
        BookService bookService = (BookService) context.getBean("bookService");

        // Use the bookService to perform some operations...
        // For example, you could call some method on bookService here

        System.out.println("Spring IoC Container configured successfully!");
    }
}
