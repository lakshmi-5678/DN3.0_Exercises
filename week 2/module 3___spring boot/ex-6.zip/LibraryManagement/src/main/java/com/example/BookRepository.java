package com.example;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {
    // Implementation of BookRepository
    public void someRepositoryMethod() {
        System.out.println("BookRepository method called.");
    }
}
