package com.example;

import org.springframework.stereotype.Service;

@Service
public class BookService {

    private BookRepository bookRepository;

    // Setter method for dependency injection
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Example method using BookRepository
    public void performService() {
        System.out.println("Performing service with BookRepository.");
    }
}
