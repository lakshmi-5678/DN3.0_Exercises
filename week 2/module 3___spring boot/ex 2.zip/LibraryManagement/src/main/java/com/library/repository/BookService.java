package com.library.repository;

public class BookService {
    public void printMessage() {
        System.out.println("Book repository message.");
    }
}

