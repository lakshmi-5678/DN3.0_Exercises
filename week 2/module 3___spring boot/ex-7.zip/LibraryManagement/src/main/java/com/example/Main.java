package com.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
    public static void main(String[] args) {
       
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        BookService bookServiceConstructor = (BookService) context.getBean("bookServiceConstructor");
        System.out.println("Testing constructor injection:");
        bookServiceConstructor.performService();

        BookService bookServiceSetter = (BookService) context.getBean("bookServiceSetter");
        System.out.println("Testing setter injection:");
        bookServiceSetter.performService();
    }
}
