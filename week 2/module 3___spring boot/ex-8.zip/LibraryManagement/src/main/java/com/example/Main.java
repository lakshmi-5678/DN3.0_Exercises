package com.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
    public static void main(String[] args) {
        // Load the Spring context from applicationContext.xml
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        // Retrieve the BookService bean with constructor injection
        BookService bookServiceConstructor = (BookService) context.getBean("bookServiceConstructor");
        System.out.println("Testing constructor injection with AOP:");
        bookServiceConstructor.performService();

        // Retrieve the BookService bean with setter injection
        BookService bookServiceSetter = (BookService) context.getBean("bookServiceSetter");
        System.out.println("Testing setter injection with AOP:");
        bookServiceSetter.performService();
    }
}
