package com.yourcompany.bookstore.controller;

import com.yourcompany.bookstore.model.Book;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/books")
public class BookController {

    private List<Book> books = new ArrayList<>();


    public BookController() {
        books.add(new Book(1L, "The Catcher in the Rye", "J.D. Salinger", 10.99, "9780316769488"));
        books.add(new Book(2L, "To Kill a Mockingbird", "Harper Lee", 8.99, "9780061120084"));
        books.add(new Book(3L, "1984", "George Orwell", 9.99, "9780451524935"));
    }

    @GetMapping
    public List<Book> getAllBooks(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String author) {
        if (title != null && author != null) {
            return books.stream()
                        .filter(book -> book.getTitle().equalsIgnoreCase(title) && book.getAuthor().equalsIgnoreCase(author))
                        .collect(Collectors.toList());
        } else if (title != null) {
            return books.stream()
                        .filter(book -> book.getTitle().equalsIgnoreCase(title))
                        .collect(Collectors.toList());
        } else if (author != null) {
            return books.stream()
                        .filter(book -> book.getAuthor().equalsIgnoreCase(author))
                        .collect(Collectors.toList());
        } else {
            return books;
        }
    }

    @GetMapping("/{id}")
    public Book getBookById(@PathVariable Long id) {
        return books.stream()
                    .filter(book -> book.getId().equals(id))
                    .findFirst()
                    .orElse(null);
    }

    @PostMapping
    public Book addBook(@RequestBody Book book) {
        books.add(book);
        return book;
    }

    @PutMapping("/{id}")
    public Book updateBook(@PathVariable Long id, @RequestBody Book updatedBook) {
        Book book = books.stream()
                         .filter(b -> b.getId().equals(id))
                         .findFirst()
                         .orElse(null);
        if (book != null) {
            book.setTitle(updatedBook.getTitle());
            book.setAuthor(updatedBook.getAuthor());
            book.setPrice(updatedBook.getPrice());
            book.setIsbn(updatedBook.getIsbn());
        }
        return book;
    }

    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable Long id) {
        books.removeIf(book -> book.getId().equals(id));
    }
}
