package com.springboot.EmployeeManagementSystem.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.EmployeeManagementSystem.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	//Derived query methods
	List<Employee> findByName(String name);
	
	List<Employee> findByDepartmentId(int departmentId);
	
	List<Employee> findByEmail(String email);

}
