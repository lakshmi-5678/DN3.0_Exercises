package com.code.employee.entity;


	import lombok.AllArgsConstructor;
	import lombok.Getter;

	@Getter
	@AllArgsConstructor
	public class EmployeeDTO {

	    private String name;
	    private String email;
	    private double salary;
	    private String deptid;
		public String getName() {
			// TODO Auto-generated method stub
			return this.name;
		}
		public String getDeptid() {
			// TODO Auto-generated method stub
			return this.deptid;
		}
		public Object getEmail() {
			// TODO Auto-generated method stub
			return this.email;
		}
		public Object getSalary() {
			// TODO Auto-generated method stub
			return this.salary;
		}
	}


