package a1;
public class AmazonPayGateway {
    public void pay(double amount) {
        System.out.println("Payment of $" + amount + " processed through Amazon Pay.");
    }
}
