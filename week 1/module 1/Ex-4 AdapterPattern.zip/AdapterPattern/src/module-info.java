/**
 * 
 */
/**
 * 
 */
module AdapterPattern {
}