package a7;

public interface Command {
	void execute();
}
