package a6;

public interface PaymentStrategy {
	void pay(double amount);
}
