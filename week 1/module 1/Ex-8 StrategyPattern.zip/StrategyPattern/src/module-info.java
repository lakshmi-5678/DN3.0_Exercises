/**
 * 
 */
/**
 * 
 */
module StrategyPattern {
}