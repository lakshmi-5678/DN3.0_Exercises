package a2;

public class DecoratorPatternTest {
	public static void main(String[] args) {
        // Create a basic Email Notifier
        Notifier emailNotifier = new EmailNotifier();
        emailNotifier.send("Hello, this is a basic email notification!");

        System.out.println("\nAdding SMS Notification:");
        // Decorate with SMS Notifier
        Notifier smsNotifier = new SMSNotifierDecorator(emailNotifier);
        smsNotifier.send("Hello, this is an email with SMS notification!");
    }
}
