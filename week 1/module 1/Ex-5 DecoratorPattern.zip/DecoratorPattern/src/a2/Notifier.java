package a2;
	public interface Notifier {
	    void send(String message);
	}
