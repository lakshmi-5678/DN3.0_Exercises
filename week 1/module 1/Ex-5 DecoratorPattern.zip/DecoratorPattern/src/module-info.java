/**
 * 
 */
/**
 * 
 */
module DecoratorPattern {
}