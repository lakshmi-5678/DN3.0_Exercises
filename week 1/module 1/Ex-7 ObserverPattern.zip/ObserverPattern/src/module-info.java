/**
 * 
 */
/**
 * 
 */
module ObserverPattern {
}