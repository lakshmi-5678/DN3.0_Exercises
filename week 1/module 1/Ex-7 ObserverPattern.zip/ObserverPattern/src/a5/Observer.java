package a5;
	public interface Observer {
	    void update(double stockPrice);
	}
