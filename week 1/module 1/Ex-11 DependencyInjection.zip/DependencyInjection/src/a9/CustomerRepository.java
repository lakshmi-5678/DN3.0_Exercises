package a9;

public interface CustomerRepository {
	Customer findCustomerById(String id);

}
