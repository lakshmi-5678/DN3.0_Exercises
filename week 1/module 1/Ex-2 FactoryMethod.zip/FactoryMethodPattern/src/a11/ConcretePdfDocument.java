package a11;
public class ConcretePdfDocument extends PdfDocument {
    @Override
    public void open() {
        System.out.println("Opening a specific PDF document.");
    }
}
