package a11;

public interface Document {
	void open();
}
