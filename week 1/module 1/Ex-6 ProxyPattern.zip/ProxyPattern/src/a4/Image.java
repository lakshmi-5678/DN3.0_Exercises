package a4;

public interface Image {
	void display();

}
