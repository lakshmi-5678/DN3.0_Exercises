package c4;
import java.util.Arrays;

public class LibraryManagementSystem {

    public static Book linearSearchByTitle(Book[] books, String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null; 
    }

    public static Book binarySearchByTitle(Book[] books, String title) {
        int low = 0;
        int high = books.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            int cmp = books[mid].getTitle().compareToIgnoreCase(title);

            if (cmp == 0) {
                return books[mid]; 
            }
            if (cmp < 0) {
                low = mid + 1; 
            } else {
                high = mid - 1; 
            }
        }
        return null; 
    }
}
